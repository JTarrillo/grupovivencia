<?php 

echo "Hola";
die();
?>