<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddPaidAmountToCommissionReports extends Migration
{
    public function up()
    {
        $fields = [
            'paid_amount' => [
                'type' => 'DECIMAL',
                'constraint' => '10,2',
                'default' => 0.00,
                'null' => false,
                'after' => 'total_amount'
            ]
        ];
        
        $this->forge->addColumn('commission_reports', $fields);
    }

    public function down()
    {
        $this->forge->dropColumn('commission_reports', 'paid_amount');
    }
}