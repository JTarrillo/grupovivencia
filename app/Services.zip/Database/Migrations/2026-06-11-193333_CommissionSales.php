<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CommissionSales extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'report_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'project_name' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'client_name' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'manzana' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'lote' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
            ],
            'payment_type' => [
                'type'       => 'VARCHAR',
                'constraint' => '100', // Cuota, Inicial, Reserva
            ],
            'deposit_number' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'deposit_amount' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
            ],
            'percentage' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
            ],
            'commission_amount' => [
                'type'       => 'DECIMAL',
                'constraint' => '10,2',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('report_id', 'commission_reports', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('commission_sales');
    }

    public function down()
    {
        $this->forge->dropTable('commission_sales');
    }
}
